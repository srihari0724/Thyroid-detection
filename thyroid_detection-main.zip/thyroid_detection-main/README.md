# thyroid_detection
